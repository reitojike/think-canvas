
 dev37_google_apis_x86_64_Pixel_937����"Android virtual processor*x86_64*	arm64-v8a2Google:emulator-5556B dev37_google_apis_x86_64_Pixel_9Rsdk_gphone64_x86_64